const heroButton = document.querySelector('.custom_btn_primary_hero');
const aboutButton = document.querySelector('.custom_btn_primary_about');
const processButton = document.querySelector('.custom_btn_transparent');
const playButton = document.querySelector('.custom_btn_primary_play');

// const buttons = document.querySelectorAll('.custom_btn_primary')

const buttons = document.querySelectorAll('.custom_btn')

// const buttons = [heroButton, aboutButton, processButton, playButton]


// const mEnter = function mouseEntersButton(button) {
    
//     const spans = button.querySelectorAll('span')

//     spans.forEach((span, index) => {
//         setTimeout(() => {
//             span.classList.add('hover');
//         }, index * 50)
//     });
// }

// const  mLeave = function mouseLeavesButton(button) {

//     const spans = button.querySelectorAll('span')

//     spans.forEach((span, index) => {
//         setTimeout(() => {
//             span.classList.remove('hover');
//         }, index * 50)
//     });
//     console.log('leaves')
    
// }



// buttons.forEach(button => {
//     const text = button.textContent
//     button.innerHTML = '';

//     for (const char of text) {
//         const span = document.createElement('span');
//         span.textContent = char === ' ' ? '\u00A0' : char;
//         button.appendChild(span);
//     }
    
// })
//     console.log('hi');
    

//     button.addEventListener('mouseenter', mouseEntersButton(button))
//     button.addEventListener('mouseleave', mouseLeavesButton(button))
// });




// heroButton.addEventListener('mouseenter', mEnter)
// heroButton.addEventListener('mouseleave', mLeave)

// aboutButton.addEventListener('mouseenter', mouseEntersButton(aboutButton))
// aboutButton.addEventListener('mouseleave', mouseLeavesButton(aboutButton))

// processButton.addEventListener('mouseenter', mouseEntersButton(processButton))
// processButton.addEventListener('mouseleave', mouseLeavesButton(processButton))

// playButton.addEventListener('mouseenter', mouseEntersButton(playButton))
// playButton.addEventListener('mouseleave', mouseLeavesButton(playButton))


// const spans = button.querySelectorAll('span')






// function customButton(button) {
//     const text = button.textContent
//     button.innerHTML = '';
    
//     for (const char of text) {
//         const span = document.createElement('span');
//         span.textContent = char === ' ' ? '\u00A0' : char;
//         button.appendChild(span);
//     }


//     const spans = button.querySelectorAll('span')

//     button.addEventListener('mouseenter', () => {
//         spans.forEach((span, index) => {
//             setTimeout(() => {
//                 span.classList.add('hover');
//             }, index * 50)
//         });
//     })

//     button.addEventListener('mouseleave', () => {
//         spans.forEach((span, index) => {
//             setTimeout(() => {
//                 span.classList.remove('hover');
//             }, index * 50)
//         });
//     })
// }






buttons.forEach(button => {
    const text = button.textContent
    button.innerHTML = '';

    for (const char of text) {
        const span = document.createElement('span');
        span.textContent = char === ' ' ? '\u00A0' : char;
        button.appendChild(span);
    }
    
    const spans = button.querySelectorAll('span')
    
    button.addEventListener('mouseenter', () => {
        spans.forEach((span, index) => {
            setTimeout(() => {
                span.classList.add('hover');
            }, index * 50)
        });

    })
    
    button.addEventListener('mouseleave', () => {
        spans.forEach((span, index) => {
            setTimeout(() => {
                span.classList.remove('hover');
            }, index * 50)
        });
    })
})





// const buttons = document.querySelectorAll('.custom_btn_primary');

// buttons.forEach(button => {
//     const text = button.textContent
//     button.innerHTML = '';

//     for (const char of text) {
//         const span = document.createElement('span');
//         span.textContent = char === ' ' ? '\u00A0' : char;
//         button.appendChild(span);
//     }
    
//     const spans = button.querySelectorAll('span')
    
//     button.addEventListener('mouseenter', () => {
//         spans.forEach((span, index) => {
//             setTimeout(() => {
//                 span.classList.add('hover');
//             }, index * 50)
//         });
//     })
    
//     button.addEventListener('mouseleave', () => {
//         spans.forEach((span, index) => {
//             setTimeout(() => {
//                 span.classList.remove('hover');
//             }, index * 50)
//         });
//     })
// })




/////////////------------------ fetch ----------------////////////////////

// function list(data) {
//     data.forEach(el => console.log(el.title + ' - ' + el.price))
// }


// fetch('https://6904c2fa6b8dabde496507c0.mockapi.io/api/products/products')
//     .then(response => {

//         if(!response.ok) {
//             throw new Error('Could not fetch resource');
//         }
//         return response.json();
//     })
//     // .then(response => console.log(response))
//     .then(data => console.log(data))
//     .catch(error => console.error(error))



// fetchData();

// async function fetchData() {

//     try{

//         const productName = document.getElementById('productName').value.toLowerCase();
//         const response = await fetch(`https://6904c2fa6b8dabde496507c0.mocapi.io/api/products/${ }`)
    
//         if (!response.ok){
//             throw new Error('couldnt fetch resource');
//         }
//         const data = await response.json();
//         console.log(data);
//     }
//     catch(error){
//         console.error(error)
//     }
// }














