
// get fetch data

const getData = fetch('https://6904c2fa6b8dabde496507c0.mockapi.io/api/products/products')
    .then(response => {
        return response.json();
    })
    .then(data => {
        renderCards(data);
    });



// ----------------------  products  -----------------------//
 

function renderCards(data) {
    data.forEach(product => {
        const card = document.createElement('div');
        card.classList.add('card');

        const imgWrap = document.createElement('div');
        imgWrap.classList.add('img-wrap');

        const img = document.createElement('img');
        img.setAttribute('src', product.img);
        imgWrap.appendChild(img);
        card.appendChild(imgWrap);


        const cardInfo = document.createElement('div')
        cardInfo.classList.add('card__info');
        card.appendChild(cardInfo)

        const cardTitle = document.createElement('h4')
        cardTitle.classList.add('card__title', 'text');
        cardTitle.innerText = product.title
        cardInfo.appendChild(cardTitle);

        const cardPricesWrap = document.createElement('div')
        cardPricesWrap.classList.add('card__prices-wrap');
        cardInfo.appendChild(cardPricesWrap);

        const cardPrice = document.createElement('p')
        cardPrice.classList.add('card__price', 'text');
        cardPrice.innerText = '$' + product.price
        cardPricesWrap.appendChild(cardPrice);

        const cardDiscount = document.createElement('p')
        cardDiscount.classList.add('card__discount', 'text');
        cardDiscount.innerText = product.discount == 0 ? '' : '$' + product.discount
        cardPricesWrap.appendChild(cardDiscount);


        document.getElementById('cards-container').appendChild(card);
    });
}


/* hide & show functions */

function hideElement(element) {
    if (element.classList.contains('hidden')){
        return 
    }
    element.classList.add('hidden')
}

function showElement(element) {
    if (!(element.classList.contains('hidden'))){
        return 
    }
    element.classList.remove('hidden')    
}



/* search functional */

const searchField = document.getElementById('search-cards');
const productsMenu = document.getElementById('cards-container');
const cardProducts = getElementsByClassName('card')

function search(searchQuery) {
    return cardProducts.filter(item => 
        item.toLowerCase().includes(searchQuery.toLowerCase())
    );
}



function showSearchResults(searchResults) {
    productsMenu.innerHTML = '';

    if (!searchResults.length) {
        productsMenu.innerHTML = '<div class="card">No products were found :c</div>';
        return;
    }

    searchResults.forEach(card => {
        const cardElement = document.createElement('div');
        cardElement.classList.add('card');
        cardElement.textContent = card;
        productsMenu.appendChild(cardElement);
    });
}




const searchButton = document.getElementById('search-btn')

searchButton.addEventListener('click', (e) => {
    e.preventDefault();
    const searchQuery = searchField.value.trim();
    const searchResults = search(searchQuery)

    showSearchResults(searchResults);
})















